﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
    class Customer
    {
        private string name;
        private string email;
        private string password;
        public Customer(string name, string email, string password)
        {
            this.name = name;
            this.email = email;
            this.password = password;
        }
        public string getName()
        {
            return name;
        }
        public string getEmail()
        {
            return email;
        }
        public string getPassword()
        {
            return password;
        }
        public void changePassword(string password)
        {
            this.password = password;
        }
        public void changeEmail(string email)
        {
            this.email = email;
        }
    }
}
