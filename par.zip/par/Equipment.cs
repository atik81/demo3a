﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
    class Equipment
    {
        private string id;
        private string name;
        private double rentPerHour;
        public Equipment(string id, string name, double rentPerHour)
        {
            this.id = id;
            this.name = name;
            this.rentPerHour = rentPerHour;
        }
        public string getId()
        {
            return id;
        }
        public string getName()
        {
            return name;
        }
        public double getRent()
        {
            return rentPerHour;
        }
        public void setName(string name)
        {
            this.name = name;
        }
        public void setRent(double rent)
        {
            rentPerHour = rent;
        }

    }
}
