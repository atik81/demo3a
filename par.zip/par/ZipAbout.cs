﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
    class ZipAbout
    {
        private Vehicle[] vehicles;
        private Customer[] customers;
        private Equipment[] equipments;
        private Order[] orders;
        public ZipAbout()
        {
            vehicles = new Vehicle[0];
            equipments = new Equipment[0];
            customers = new Customer[0];
            orders = new Order[0];
        }
        public void addVehicle(Vehicle vehicle)
        {
            Vehicle[] temp = vehicles;
            vehicles = new Vehicle[temp.Length];
            for (int i = 0; i < temp.Length; i++)
            {
                vehicles[i] = temp[i];
            }
            vehicles[vehicles.Length - 1] = vehicle;
        }
        public void registerCustomer(string name, string email, string password)
        {
            Customer[] temp = customers;
            customers = new Customer[temp.Length];
            for (int i = 0; i < temp.Length; i++)
            {
                customers[i] = temp[i];
            }
            customers[customers.Length - 1] = new Customer(name, email, password);
        }

        public void addEquipment(Equipment equipment)
        {
            Equipment[] temp = equipments;
            equipments = new Equipment[temp.Length];
            for (int i = 0; i < temp.Length; i++)
            {
                equipments[i] = temp[i];
            }
            equipments[equipments.Length - 1] = equipment;
        }

        public void createOrder(string id, Vehicle vehicle, Customer customer)
        {
            Order[] temp = orders;
            orders = new Order[temp.Length];
            for (int i = 0; i < temp.Length; i++)
            {
                orders[i] = temp[i];
            }
            orders[orders.Length - 1] = new Order(id, customer, vehicle);
        }

        public Vehicle[] getVehicles()
        {
            return vehicles;
        }

        public Customer[] getCustomers()
        {
            return customers;
        }

        public Equipment[] getEquipments()
        {
            return equipments;
        }
    }
}
