﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
   
        // All subscribers ot offers should implement this.
        public interface IOfferSubscriber
        {
            public void notify(string message);
        }



    

}
