﻿using ATIK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
    class Segway : Vehicle
    {
        private int? batteryTiming;
        public Segway(string? vehicleId, double? rentPerHour, int? batteryTiming) : base(vehicleId, rentPerHour)
        {
            this.batteryTiming = batteryTiming;
        }
        public void setBatteryTiming(int battery)
        {
            batteryTiming = battery;
        }
        public int? getBatteryTiming()
        {
            return batteryTiming;
        }

        public override void print()
        {
            base.print();
            System.Console.WriteLine("Battery Timings: " + batteryTiming);
        }
    }
}
