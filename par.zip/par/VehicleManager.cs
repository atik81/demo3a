﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
    class VehicleManager
    {
        private static List<Vehicle> vehicles = new List<Vehicle>();
        private static List<Booking> bookings = new List<Booking>();

        public static bool BookVehicle(Customer? customer, string? vehicleId)
        {
            foreach (Vehicle vehicle in vehicles)
            {
                if (vehicle.getVehicleId() == vehicleId)
                {
                    if (vehicle.isBooked())
                    {
                        return false;
                    }
                    else
                    {
                        Booking booking = new Booking(customer, vehicle);
                        bookings.Add(booking);
                    }
                }
            }
            return false;
        }

        public static void printAvailableVehicles()
        {
            foreach (Vehicle vehicle in vehicles)
            {
                if (!vehicle.isBooked())
                {
                    vehicle.print();
                }
            }
        }

        public static void addVehicle(Vehicle vehicle)
        {
            vehicles.Add(vehicle);
        }

        public static void printBookings()
        {
            foreach (Vehicle vehicle in vehicles)
            {
                if (vehicle.isBooked())
                {
                    vehicle.print();
                }
            }
        }

    }
}
