﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
    class CustomerManager
    {
        private static List<Customer> customers = new List<Customer>();

        public static Customer addCustomer(string? name, string? email, string? password)
        {
            Customer customer = new Customer(name, email, password);
            customers.Add(customer);
            return customer;
        }

        public static Customer? getCustomer(string? email)
        {
            foreach (Customer customer in customers)
            {
                if (customer.getEmail() == email)
                {
                    return customer;
                }
            }
            return null;
        }

        public static bool removeCustomer(string? email)
        {
            foreach (Customer customer in customers)
            {
                if (customer.getEmail() == email)
                {
                    customers.Remove(customer);
                    return true;
                }
            }
            return false;
        }
    }
}
