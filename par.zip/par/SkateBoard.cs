﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
    class SkateBoard : Vehicle
    {
        private double boardLength;
        public SkateBoard(string vehicleId,  double rentPerHour, int batteryTimingdouble, double boardLength) : base(vehicleId, rentPerHour)
        {
            this.boardLength = boardLength;
        }
        public void setLength(double boardLength)
        {
            this.boardLength = boardLength;
        }
        public double getLength()
        {
            return boardLength;
        }

        public override void print()
        {
            base.print();
            System.Console.WriteLine("Board Length: " + boardLength);
        }
    }
}
