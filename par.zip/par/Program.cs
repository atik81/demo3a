﻿using ATIK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("MENU\n1. Add Vehicle\n2. Add User \n3. Display Available Vehicles\n4. Create a Booking \n5. EXIT \nEnter your choice  : ");

            string exit = "";
            while (true)
            {
                {
                    string? choice = Console.ReadLine();
                    if (choice == "1")
                    {
                        Console.Write("Enter Vehicle Type: ");
                        string? vehicleType = Console.ReadLine();
                        vehicleType?.ToLower();
                        if (VehicleFactory.isValidType(vehicleType))
                        {

                            Console.Write("Enter Vehicle Id: ");
                            string? vehicleId = Console.ReadLine();
                            Console.Write("Enter Rent Per Hour: ");
                            double? rentPerHour = Convert.ToDouble(Console.ReadLine());
                            Console.Write("Enter Battery Timing: ");
                            int batteryTiming = Convert.ToInt32(Console.ReadLine());

                            Vehicle? vehicle = VehicleFactory.getVehicle(vehicleType, vehicleId, rentPerHour, batteryTiming);
                            if (vehicle != null)
                            {
                                vehicle.print();
                            }
                            else
                            {
                                Console.WriteLine("Vehicle could not be added");
                            }

                            Console.WriteLine("Vehicle Added Successfully");
                        }
                        else
                        {
                            Console.WriteLine("Vehicle Type is Invalid");
                        }
                        

                    }
                    else if (choice == "2")
                    {
                        Console.Write("Enter User Name: ");
                        string? userName = Console.ReadLine();
                        Console.Write("Enter Email: ");
                        string? email = Console.ReadLine();
                        Console.Write("Enter Password: ");
                        string? password = Console.ReadLine();

                        Customer customer = CustomerManager.addCustomer(userName, email, password);
                        if (customer != null)
                        {
                            Console.WriteLine("User has been created!");
                        }
                        else
                        {
                            Console.WriteLine("User could not be created!");
                        }
                        
                    }
                    else if (choice == "3")
                    {
                        Console.WriteLine("Available Vehicles: ");
                        VehicleManager.printAvailableVehicles();
                        
                    }

                    else if (choice == "4")
                    {
                        Console.Write("Enter User email: ");
                        string? userEmail = Console.ReadLine();
                        Console.Write("Enter your Password: ");
                        string? email = Console.ReadLine();

                        Console.Write("Enter Vehicle Id: ");
                        string? vehicleId = Console.ReadLine();
                       

                        Customer? customer = CustomerManager.getCustomer(userEmail);

                        if (customer != null)
                        {
                            bool booking = VehicleManager.BookVehicle(customer, vehicleId);
                            if (booking == false)
                            {
                                Console.WriteLine("Booking has been created!");
                                Offer familyOffer = new Offer("family");
                                OfferSubscriber s1 = new OfferSubscriber("ahmed family");
                                familyOffer.addSubscriber(s1);

                                OfferSubscriber s2 = new OfferSubscriber("khan family");
                                familyOffer.addSubscriber(s2);

                                OfferSubscriber s3 = new OfferSubscriber("Sheak family");
                                familyOffer.addSubscriber(s3);

                                familyOffer.makeAvailable();
                                Offer groupOffer = new Offer("groups");
                                OfferSubscriber g1 = new OfferSubscriber("Manchester city football club");
                                groupOffer.addSubscriber(g1);
                                OfferSubscriber g2 = new OfferSubscriber("liverepool football club");
                                groupOffer.addSubscriber(g2);
                                groupOffer.makeAvailable();

                            }
                            else
                            {
                                Console.WriteLine("Sorry, the vehicle is already booked");
                            }
                            
                            

                        }
                        else
                        {
                            Console.WriteLine("Invalid User Email.");
                           



                        }


                    }
                    else if (choice == "5")
                    {
                        Console.WriteLine("Thank You");
                        break;
                    }
                   
                    
                    
                }
            }

           
            
           


                


            }

        }
    }

