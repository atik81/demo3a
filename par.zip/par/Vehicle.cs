﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
    abstract class Vehicle
    {
        protected string? vehicleId;
        protected double? rentPerHour;
        protected bool booked;
        protected Customer customer;
        public Vehicle(string? vehicleId,  double? rentPerHour)
        {
            this.vehicleId = vehicleId;
            this.rentPerHour = rentPerHour;
            this.booked = false;
        }
        public void setVehicleId(string id)
        {
            this.vehicleId = id;
        }
        public void setRent(double rent)
        {
            rentPerHour = rent;
        }

        public string? getVehicleId()
        {
            return vehicleId;
        }
        public double? getRent()
        {
            return rentPerHour;
        }
       
        public void book()
        {
            booked = true;
        }
        public void unBook()
        {
            booked = false;
        }

        public bool isBooked()
        {
            return booked;
        }

        public virtual void print()
        {
            System.Console.WriteLine("Vehicle Id: " + vehicleId);

            System.Console.WriteLine("Rent per Hour: " + rentPerHour);
            if (booked)
            {
                System.Console.WriteLine("Booking Status: Booked");
            }
            else
            {
                System.Console.WriteLine("Booking Status: Not Booked");
            }
        }
    }
}
