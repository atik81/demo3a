﻿using ATIK;

namespace ATIK
{
    class Booking
    {
        Vehicle? vehicle;
        Customer? customer;

        public Booking(Customer? customer, Vehicle vehicle)
        {
            this.customer = customer;
            this.vehicle = vehicle;
        }
    }
}
