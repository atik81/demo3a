﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
    class Order
    {
        private string orderId;
        private Customer customer;
        private Vehicle vehicle;
        private Equipment[] equipments;
        public Order(string orderId, Customer customer, Vehicle vehicle)
        {
            this.orderId = orderId;
            this.customer = customer;
            this.vehicle = vehicle;
            this.equipments = new Equipment[0];
        }
        public string getOrderId()
        {
            return orderId;
        }
        public Customer getCustomer()
        {
            return customer;
        }
        public Vehicle getVehicle()
        {
            return vehicle;
        }
        public Equipment[] getEquipments()
        {
            return equipments;
        }
        public void addEquipmentTaken(Equipment equipment)
        {
            Equipment[] temp = equipments;
            equipments = new Equipment[temp.Length];
            for (int i = 0; i < temp.Length; i++)
            {
                equipments[i] = temp[i];
            }
            equipments[equipments.Length - 1] = equipment;
        }
    }
}
