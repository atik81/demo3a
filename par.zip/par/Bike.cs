﻿using ATIK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
    class Bike : Vehicle
    {
        private string? registrationNumber;
        private int? batteryTiming;
        public Bike(string? vehicleId,  double? rentPerHour, int? batteryTiming) : base(vehicleId, rentPerHour)
        {
            this.batteryTiming = batteryTiming;
            this.registrationNumber = "NA";

        }
        public Bike(string? vehicleId, double? rentPerHour, string? registrationNumber) : base(vehicleId, rentPerHour)
        {
            this.registrationNumber = registrationNumber;
        }
        public string? getRegistrationNumber()
        {
            return registrationNumber;
        }

        public override void print()
        {
            base.print();
            System.Console.WriteLine("Registration Number: " + registrationNumber);
        }
    }
}
