﻿using ATIK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATIK
{
    class VehicleFactory
    {
        public static bool isValidType(string? type)
        {
            if (type == "bike" || type == "scooter" || type == "segway")
            {
                return true;
            }
            return false;
        }
        public static Vehicle? getVehicle(string? vehicleType, string? vehicleId, double? rentPerHour, int? batteryTiming)
        {
            Vehicle vehicle;
            if (vehicleType == "bike")
            {
                vehicle = new Bike(vehicleId, rentPerHour, batteryTiming);
            }
            else if (vehicleType == "scooter")
            {
                vehicle = new Scooter(vehicleId, rentPerHour, batteryTiming);
            }
            else if (vehicleType == "segway")
            {
                vehicle = new Segway(vehicleId, rentPerHour, batteryTiming);
            }
            else
            {
                return null;
            }
            VehicleManager.addVehicle(vehicle);
            return vehicle;
        }

    }
}
